import{aw as s,ax as e}from"./index-Cw6WSGfP.js";function n(a,t){const r=s(a);return isNaN(t)?e(a,NaN):(t&&r.setDate(r.getDate()+t),r)}function i(a,t){return n(a,-t)}export{n as a,i as s};
//# sourceMappingURL=subDays-CB2Qx0DK.js.map
